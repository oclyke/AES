/**
  ******************************************************************************
  * File Name          : main.c
  * Description        : Main program body
  ******************************************************************************
  * This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * Copyright (c) 2018 STMicroelectronics International N.V. 
  * All rights reserved.
  *
  * Redistribution and use in source and binary forms, with or without 
  * modification, are permitted, provided that the following conditions are met:
  *
  * 1. Redistribution of source code must retain the above copyright notice, 
  *    this list of conditions and the following disclaimer.
  * 2. Redistributions in binary form must reproduce the above copyright notice,
  *    this list of conditions and the following disclaimer in the documentation
  *    and/or other materials provided with the distribution.
  * 3. Neither the name of STMicroelectronics nor the names of other 
  *    contributors to this software may be used to endorse or promote products 
  *    derived from this software without specific written permission.
  * 4. This software, including modifications and/or derivative works of this 
  *    software, must execute solely and exclusively on microcontroller or
  *    microprocessor devices manufactured by or for STMicroelectronics.
  * 5. Redistribution and use of this software other than as permitted under 
  *    this license is void and will automatically terminate your rights under 
  *    this license. 
  *
  * THIS SOFTWARE IS PROVIDED BY STMICROELECTRONICS AND CONTRIBUTORS "AS IS" 
  * AND ANY EXPRESS, IMPLIED OR STATUTORY WARRANTIES, INCLUDING, BUT NOT 
  * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A 
  * PARTICULAR PURPOSE AND NON-INFRINGEMENT OF THIRD PARTY INTELLECTUAL PROPERTY
  * RIGHTS ARE DISCLAIMED TO THE FULLEST EXTENT PERMITTED BY LAW. IN NO EVENT 
  * SHALL STMICROELECTRONICS OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
  * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, 
  * OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF 
  * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING 
  * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
  * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_hal.h"
#include "dma.h"
#include "fatfs.h"
#include "i2c.h"
#include "sdio.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "usb_device.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
#include "serial.h"
#include "STN2120.h"
#include "LIS3DH.h"
#include "LIS3MDL.h"
#include "FXAS21002C.h"
#include "LIDARLITEV3.h"

#include <math.h>



#define ERRORLED_GPIO_Port 	ULED1_GPIO_Port		// Error handling LED
#define ERRORLED_Pin 		ULED1_Pin

#define FTDI	&serial6						// More convenient definitions for the serial ports
#define BLU		&serial2
#define STN		&serial1

#define NUM_LEDS 102

/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
STN2120_HandleTypeDef			OBD;	// Enables use of the STN2120 OBD interpreter IC
LIS3DH_HandleTypeDef			acc;	// Accelerometer
LIS3MDL_HandleTypeDef			mag;	// Magnetometer
FXAS21002C_HandleTypeDef		gyro;	// Gyroscope
LIDARLITEV3_HandleTypeDef		lidar;	// Lidar sensor


volatile uint8_t Cintake = 0;
volatile uint8_t Ccoolant = 0;
volatile uint8_t kmh = 0;
volatile uint16_t rpm4 = 0;

volatile uint8_t temp_counter = 0;

uint8_t led_buff[(NUM_LEDS+2)*4];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void setup_serial( void );
void setup_sensors( void );
void setup_obd( void );
void setup_leds( void );
void setup_timers( void );

/* USER CODE END PFP */

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_I2C1_Init();
  MX_SDIO_SD_Init();
  MX_SPI1_Init();
  MX_SPI2_Init();
  MX_SPI3_Init();
  MX_SPI4_Init();
  MX_SPI5_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_USART6_UART_Init();
  MX_FATFS_Init();
  //MX_USB_DEVICE_Init();
  MX_TIM2_Init();
  MX_TIM3_Init();

  /* USER CODE BEGIN 2 */
  setup_serial();
  setup_sensors();
  setup_obd();
  setup_leds();
  setup_timers();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

  serial_println(FTDI, "AccX, AccY, AccZ, MagX, MagY, MagZ, GyroX, GyroY, GyroZ, LidarD, LidarV, 4rpm, kmh, Cintake, Ccoolant, BRK, LTS, RTS, REV");

  while (1)
  {
//	  HAL_Delay(3000);
//	  serial_println(FTDI, "Hello world!");

	rpm4 = STN2120_get_4rpm(&OBD);
	HAL_Delay(100);
	kmh = STN2120_get_kmh(&OBD);
	HAL_Delay(100);
	Ccoolant = STN2120_get_C_coolant(&OBD);
	HAL_Delay(100);
	Cintake = STN2120_get_C_intake(&OBD);
	HAL_Delay(100);








  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */

  }
  /* USER CODE END 3 */

}

/** System Clock Configuration
*/
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;

    /**Configure the main internal regulator output voltage 
    */
  __HAL_RCC_PWR_CLK_ENABLE();

  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */

void setup_leds( void )
{
	HAL_SPI_MspInit(&hspi2);		// Far right LED output
	HAL_SPI_MspInit(&hspi3);		// Middle right LED output
	HAL_SPI_MspInit(&hspi4);		// Middle left LED output
	HAL_SPI_MspInit(&hspi5);		// Far left LED output


	for(uint16_t indi = 0; indi < 4; indi++)
	{
		led_buff[indi] = 0x00;
	}
	for(uint16_t indi = 1; indi < (NUM_LEDS); indi++)
		{
			led_buff[4*indi+0] = 0b11100101;
			led_buff[4*indi+1] = 0x00;
			led_buff[4*indi+2] = 0x00;
			led_buff[4*indi+3] = 0x00;
		}
	for(uint16_t indi = 4*(NUM_LEDS+1); indi < 4*(NUM_LEDS+2); indi++)
	{
			led_buff[indi] = 0xFF;
	}
}

void setup_timers( void )
{
	HAL_TIM_Base_Start_IT(&htim3);
	HAL_TIM_Base_Start_IT(&htim2);
}

void setup_sensors( void )
{
	// Perform the MSP init for onboard sensors
	HAL_SPI_MspInit(&hspi1);		// This is the SPI port for the onboard sensors
	HAL_I2C_MspInit(&hi2c1);		// I2C expansion port

	// Accelerometer
	// Associate the correct SPI port and CS pin
	acc.hspi = &hspi1;
	acc.CS_GPIO = CS_ACC_GPIO_Port;
	acc.CS_GPIO_Pin = CS_ACC_Pin;
	acc.Timeout = LIS3DH_SPI_DEFAULT_TIMEOUT;
	// Build the initialization of the accelerometer
	acc.Init.CTRL1_VAL = ( LIS3DH_ODR_400 | LIS3DH_Zen | LIS3DH_Yen | LIS3DH_Xen );
	acc.Init.CTRL2_VAL = ( LIS3DH_HPM_NORM );
	acc.Init.CTRL3_VAL = LIS3DH_CTRL_REG3_DEFAULT;
	acc.Init.CTRL4_VAL = ( LIS3DH_BDUen | LIS3DH_FS_2g | LIS3DH_HRen | LIS3DH_SIM_4 );
	acc.Init.CTRL5_VAL = LIS3DH_CTRL_REG5_DEFAULT;
	acc.Init.CTRL6_VAL = LIS3DH_CTRL_REG6_DEFAULT;
	acc.Init.TEMP_CFG_VAL = LIS3DH_TEMP_CFG_DEFAULT;
	acc.Init.FIFO_CTRL_VAL = LIS3DH_FM_BYP;
	acc.Init.INT1_CFG_VAL = LIS3DH_INTx_CFG_DEFAULT;
	acc.Init.INT2_CFG_VAL = LIS3DH_INTx_CFG_DEFAULT;
	acc.Init.CLICK_CFG_VAL = LIS3DH_CLICK_CFG_DEFAULT;

	// Magnetometer:
	// Associate the correct SPI port and CS pin
	mag.hspi = &hspi1;
	mag.CS_GPIO = CS_MAG_GPIO_Port;
	mag.CS_GPIO_Pin = CS_MAG_Pin;
	mag.Timeout = LIS3MDL_SPI_DEFAULT_TIMEOUT;
	// Build the initialization of the gyroscope
	mag.Init.CTRL_REG1_VAL = (LIS3MDL_TEMPen | LIS3MDL_OMXY_UHPM | LIS3MDL_ODR_10);
	mag.Init.CTRL_REG2_VAL = (LIS3MDL_FS_4);
	mag.Init.CTRL_REG3_VAL = (LIS3MDL_OM_CONT);
	mag.Init.CTRL_REG4_VAL = (LIS3MDL_OMZ_UHPM);
	mag.Init.CTRL_REG5_VAL = LIS3MDL_CTRL_REG5_DEFAULT;
	mag.Init.INT_CFG_VAL = LIS3MDL_INT_CFG_DEFAULT;

	// Gyroscope
	// Associate the correct SPI port and CS pin
	gyro.hspi = &hspi1;
	gyro.CS_GPIO = CS_GYRO_GPIO_Port;
	gyro.CS_GPIO_Pin = CS_GYRO_Pin;
	gyro.Timeout = FXAS21002C_SPI_DEFAULT_TIMEOUT;
	// Build the initialization of the gyroscope
	gyro.Init.CTRL_REG0_VAL = (FXAS21002C_BW_64 | FXAS21002C_FS_2000);
	gyro.Init.CTRL_REG1_VAL = (FXAS21002C_ODR_800 | FXAS21002C_MODE_ACTV);
	gyro.Init.CTRL_REG2_VAL = FXAS21002C_CTRL_REG2_DEFAULT;
	gyro.Init.CTRL_REG3_VAL = FXAS21002C_CTRL_REG3_DEFAULT;
	gyro.Init.F_SETUP_VAL = FXAS21002C_F_SETUP_DEFAULT;
	gyro.Init.RT_CFG_VAL = FXAS21002C_RT_CFG_DEFAULT;
	gyro.Init.RT_THS_VAL = FXAS21002C_RT_THS_DEFAULT;


	// Lidar
	lidar.Init.ACQ_CONFIG_REG_VAL = (LIDARLITEV3_ACQ_CONFIG_REG_DEFAULT);
	lidar.Init.COMMAND_VAL = (LIDARLITEV3_TEST_MODE_DISBLE);
	lidar.Init.MEASURE_DELAY_VAL = (LIDARLITEV3_MEASURE_DELAY_DEFAULT);
	lidar.Init.OUTER_LOOP_COUNT_VAL = (LIDARLITEV3_OUTER_LOOP_COUNT_DEFAULT);
	lidar.Init.POWER_CONTROL_VAL = (LIDARLITEV3_POWER_CONTROL_DEFAULT);
	lidar.Init.REF_COUNT_VAL_VAL = (LIDARLITEV3_REF_COUNT_VAL_DEFAULT);
	lidar.Init.SIG_COUNT_VAL_VAL = (LIDARLITEV3_SIG_COUNT_VAL_DEFAULT);
	lidar.Init.THRESHOLD_BYPASS_VAL = (LIDARLITEV3_THRESHOLD_BYPASS_DEFAULT);
	lidar.Timeout = LIDARLITEV3_I2C_TIMEOUT_DEFAULT;
	lidar.i2c_addr_7 = LIDARLITEV3_I2C_ADDRESS_DEFAULT;
	lidar.hi2c = &hi2c1;


	// Initialize all sensors
	LIS3DH_init(&acc);				// Initialize LIS3DH accelerometer
	LIS3MDL_init(&mag);				// Initialize LIS3MDL magnetometer
	FXAS21002C_init(&gyro);			// Initialize FXAS21002C gyroscope
//	LIDARLITEV3_init_continuous_measurement(&lidar, LIDARLITEV3_MEASURE_DELAY_DEFAULT, LIDARLITEV3_MEASURE_W_BIAS_CORR);
	LIDARLITEV3_init(&lidar);		// Initialize LidarLiteV3 Lidar Rangefinder
}



void setup_serial( void )
{
	// serial6
	huart6.Instance = USART6;
	huart6.Init.BaudRate = 115200;
	huart6.Init.WordLength = UART_WORDLENGTH_8B;
	huart6.Init.StopBits = UART_STOPBITS_1;
	huart6.Init.Parity = UART_PARITY_NONE;
	huart6.Init.Mode = UART_MODE_TX_RX;
	huart6.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart6.Init.OverSampling = UART_OVERSAMPLING_16;
	serial6.huart = &huart6;		// Link huart6 to serial6 (required, no other options are allowable)


	// serial2
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 115200;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;
	serial2.huart = &huart2;		// Link huart2 to serial2 (required, no other options are allowable)


	// serial1
	huart1.Instance = USART1;
	huart1.Init.BaudRate = 9600;
	huart1.Init.WordLength = UART_WORDLENGTH_8B;
	huart1.Init.StopBits = UART_STOPBITS_1;
	huart1.Init.Parity = UART_PARITY_NONE;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;
	serial1.huart = &huart1;		// Link huart1 to serial1 (required, no other options are allowable)


	// Initialize
	serial_initialize(&serial6);
	serial_initialize(&serial2);
	serial_initialize(&serial1);
}

void setup_obd( void )
{
	OBD.hserial = &serial1;
	STN2120_initialize(&OBD);
}



// CALLBACKS!
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM2)
	{
		HAL_GPIO_TogglePin(ULED2_GPIO_Port, ULED2_Pin);

			uint8_t blue = 0;
			uint8_t green = 0;
			uint8_t red = 0;
			uint8_t bright = 3;

			if(gyro.X < 32767){blue = ((gyro.X)/2)&0x00FF;}
			else{blue = ((65535-gyro.X)/2) & 0x00FF;}
			if(gyro.Y < 32767){green = ((gyro.Y)/2)&0x00FF;}
			else{green = ((65535-gyro.Y)/2) & 0x00FF;}
			if(gyro.Z < 32767){red = ((gyro.Z)/2)&0x00FF;}
			else{red = ((65535-gyro.Z)/2) & 0x00FF;}
			for(uint8_t indi = 10; indi < 20; indi++){
				  		led_buff[4*(indi+1)+1] = blue;
				  		led_buff[4*(indi+1)+2] = green;
				  		led_buff[4*(indi+1)+3] = red;
			}


			if(acc.X < 32767){blue = ((acc.X)/16)&0x00FF;}
			else{blue = ((65535-acc.X)/16) & 0x00FF;}
			if(acc.Y < 32767){green = ((acc.Y)/16)&0x00FF;}
			else{green = ((65535-acc.Y)/16) & 0x00FF;}
			if(acc.Z < 32767){red = ((acc.Z)/16)&0x00FF;}
			else{red = ((65535-acc.Z)/16) & 0x00FF;}
			for(uint8_t indi = 25; indi < 35; indi++){
				led_buff[4*(indi+1)+1] = blue;
				led_buff[4*(indi+1)+2] = green;
				led_buff[4*(indi+1)+3] = red;
			}


			if(mag.X < 32767){blue = ((mag.X)/16)&0x00FF;}
			else{blue = ((65535-mag.X)/16) & 0x00FF;}
			if(mag.Y < 32767){green = ((mag.Y)/16)&0x00FF;}
			else{green = ((65535-mag.Y)/16) & 0x00FF;}
			if(mag.Z < 32767){red = ((mag.Z)/16)&0x00FF;}
			else{red = ((65535-mag.Z)/16) & 0x00FF;}
			for(uint8_t indi = 40; indi < 50; indi++){
				led_buff[4*(indi+1)+1] = blue;
				led_buff[4*(indi+1)+2] = green;
				led_buff[4*(indi+1)+3] = red;
			}


			if(lidar.D < 32767){blue = ((lidar.D))&0x00FF;}
			else{blue = ((65535-lidar.D)) & 0x00FF;}
			if(lidar.V < 125){green = (lidar.V);}
			else{green = (255-lidar.V);}
			red = 0;
			for(uint8_t indi = 55; indi < 65; indi++){
				led_buff[4*(indi+1)+1] = blue;
				led_buff[4*(indi+1)+2] = green;
				led_buff[4*(indi+1)+3] = red;
			}



			blue = kmh*3;
			green = rpm4/110;
			red = Ccoolant;
			for(uint8_t indi = 70; indi < 80; indi++){
				led_buff[4*(indi+1)+1] = blue;
				led_buff[4*(indi+1)+2] = green;
				led_buff[4*(indi+1)+3] = red;
			}




			if(HAL_GPIO_ReadPin(BRK_GPIO_Port, BRK_Pin)){red = 255;}
			else{red = 0;}
			if(HAL_GPIO_ReadPin(LTS_GPIO_Port, LTS_Pin)){green = 255;}
			else{green = 0;}
			if(HAL_GPIO_ReadPin(RTS_GPIO_Port, RTS_Pin)){blue = 255;}
			else{blue = 0;}
			for(uint8_t indi = 85; indi < 95; indi++){
				led_buff[4*(indi+1)+1] = blue;
				led_buff[4*(indi+1)+2] = green;
				led_buff[4*(indi+1)+3] = red;
				led_buff[4*(indi+1)+0] = (0xE0 | bright);
			}


	}
	if(htim->Instance == TIM3)
	{
		HAL_GPIO_TogglePin(ULED1_GPIO_Port, ULED1_Pin);

		LIS3DH_update_accels(&acc);
		serial_print_uint32(FTDI, acc.X, 1, 6); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, acc.Y, 1, 6); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, acc.Z, 1, 6); serial_print(FTDI, ", ");


		LIS3MDL_update_vals(&mag);
		serial_print_uint32(FTDI, mag.X, 1, 6); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, mag.Y, 1, 6); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, mag.Z, 1, 6); serial_print(FTDI, ", ");


		FXAS21002C_update_vals(&gyro);
		serial_print_uint32(FTDI, gyro.X, 1, 6); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, gyro.Y, 1, 6); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, gyro.Z, 1, 6); serial_print(FTDI, ", ");


		// Lidar
		LIDARLITEV3_update_vals(&lidar);
		serial_print_uint32(FTDI, lidar.D, 1, 6); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, lidar.V, 1, 6); serial_print(FTDI, ", ");
		LIDARLITEV3_take_measurement(&lidar,LIDARLITEV3_MEASURE_NO_BIAS_CORR);

		// OBD Info: - still need to figure out how best to account for the slowness of OBD...
		serial_print_uint32(FTDI, rpm4, 1, 6); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, kmh, 1, 3); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, Ccoolant, 1, 3); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, Cintake, 1, 3); serial_print(FTDI, ", ");


		// Signal state pins
		serial_print_uint32(FTDI, HAL_GPIO_ReadPin(BRK_GPIO_Port, BRK_Pin), 1, 1); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, HAL_GPIO_ReadPin(LTS_GPIO_Port, LTS_Pin), 1, 1); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, HAL_GPIO_ReadPin(RTS_GPIO_Port, RTS_Pin), 1, 1); serial_print(FTDI, ", ");
		serial_print_uint32(FTDI, HAL_GPIO_ReadPin(REV_GPIO_Port, REV_Pin), 1, 1); serial_println(FTDI, "");


		HAL_SPI_Transmit_IT(&hspi2, led_buff, 4*(2+NUM_LEDS));
	}
	else
	{
		__NOP();
	}
}



/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  None
  * @retval None
  */
void _Error_Handler(char * file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1) 
  {
		HAL_GPIO_TogglePin(ERRORLED_GPIO_Port, ERRORLED_Pin);
		HAL_Delay(100);
  }
  /* USER CODE END Error_Handler_Debug */ 
}

#ifdef USE_FULL_ASSERT

/**
   * @brief Reports the name of the source file and the source line number
   * where the assert_param error has occurred.
   * @param file: pointer to the source file name
   * @param line: assert_param error line source number
   * @retval None
   */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
    ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */

}

#endif

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
